
// Full JSX code from Canvas (already copied and inserted)
